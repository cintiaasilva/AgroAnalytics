$(document).ready(function(){
    $(".menu").click(function(){
        $(".keep").toggleClass("width");
    });
});